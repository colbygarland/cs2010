README

if you type make, it will make the program for you!
